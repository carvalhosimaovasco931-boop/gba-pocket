(() => {
  const romPicker = document.getElementById('rom-file');
  const status = document.getElementById('status');
  const game = document.getElementById('game');
  const screenMessage = document.getElementById('screen-message');
  const fullscreenButton = document.getElementById('fullscreen');
  const DATA_PATH = 'https://cdn.emulatorjs.org/stable/data/';
  let emulatorLoaded = false;
  let loaderScript = null;
  let currentRomUrl = null;

  const keyMap = new Map();
  const buttons = document.querySelectorAll('[data-key]');

  function setStatus(message) { status.textContent = message; }

  function keyDown(key) {
    if (keyMap.has(key)) return;
    keyMap.set(key, true);
    window.dispatchEvent(new KeyboardEvent('keydown', { key, code: key === ' ' ? 'Space' : key, bubbles: true, cancelable: true }));
  }
  function keyUp(key) {
    keyMap.delete(key);
    window.dispatchEvent(new KeyboardEvent('keyup', { key, code: key === ' ' ? 'Space' : key, bubbles: true, cancelable: true }));
  }
  function releaseAll() { for (const key of [...keyMap.keys()]) keyUp(key); }

  buttons.forEach(button => {
    const key = button.dataset.key;
    const press = event => { event.preventDefault(); button.classList.add('pressed'); keyDown(key); };
    const release = event => { event.preventDefault(); button.classList.remove('pressed'); keyUp(key); };
    button.addEventListener('pointerdown', press);
    button.addEventListener('pointerup', release);
    button.addEventListener('pointercancel', release);
    button.addEventListener('pointerleave', release);
    button.addEventListener('contextmenu', event => event.preventDefault());
  });
  window.addEventListener('blur', releaseAll);
  document.addEventListener('visibilitychange', () => { if (document.hidden) releaseAll(); });

  fullscreenButton.addEventListener('click', async () => {
    const target = document.querySelector('.console');
    try {
      if (!document.fullscreenElement) await target.requestFullscreen();
      else await document.exitFullscreen();
    } catch { setStatus('Ecrã inteiro não suportado neste navegador.'); }
  });

  romPicker.addEventListener('change', () => {
    const file = romPicker.files && romPicker.files[0];
    if (!file) return;
    if (!/\.(gba|zip|7z)$/i.test(file.name)) { setStatus('Seleciona uma ROM GBA (.gba) ou arquivo compatível.'); return; }
    if (emulatorLoaded) {
      setStatus('ROM selecionada. Para trocar de jogo, recarrega a página e seleciona outra ROM.');
      return;
    }
    currentRomUrl = URL.createObjectURL(file);
    screenMessage.classList.add('hidden');
    setStatus('A carregar motor e jogo… mantém a página aberta.');
    window.EJS_player = '#game';
    window.EJS_core = 'gba';
    window.EJS_gameUrl = currentRomUrl;
    window.EJS_gameName = file.name.replace(/\.[^.]+$/, '');
    window.EJS_pathtodata = DATA_PATH;
    window.EJS_startOnLoaded = true;
    window.EJS_controlScheme = 'gba';
    window.EJS_color = '#7952a1';
    window.EJS_language = 'pt-PT';
    window.EJS_onGameStart = () => setStatus('Jogo iniciado — usa os controlos inferiores.');
    window.EJS_onLoad = () => setStatus('Motor carregado. A preparar jogo…');
    window.EJS_onError = (error) => { setStatus('Falha ao carregar o motor. Confirma Internet e tenta novamente.'); console.error('EmulatorJS error:', error); };
    loaderScript = document.createElement('script');
    loaderScript.src = DATA_PATH + 'loader.js';
    loaderScript.async = true;
    loaderScript.onerror = () => { screenMessage.classList.remove('hidden'); setStatus('Não foi possível descarregar EmulatorJS. Confirma a ligação à Internet.'); };
    document.body.appendChild(loaderScript);
    emulatorLoaded = true;
  });

  window.addEventListener('beforeunload', () => { releaseAll(); if (currentRomUrl) URL.revokeObjectURL(currentRomUrl); });
})();
