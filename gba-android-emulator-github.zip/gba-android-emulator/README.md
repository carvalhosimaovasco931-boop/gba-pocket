# GBA Pocket — Emulator

Projeto web de emulação Game Boy Advance, com interface adaptada a Android e controlos de toque na parte inferior. O núcleo de emulação é carregado por **EmulatorJS** a partir do CDN oficial; este repositório não inclui BIOS nem ROMs.


## Executar localmente

Não abras `index.html` diretamente por `file://`. Usa um servidor HTTP local:


### Python
```bash
python -m http.server 8000
```
Depois abre `http://localhost:8000`.

### Node (opcional)
```bash
npx serve .
```

## Publicar no GitHub Pages
1. Cria um repositório no GitHub e envia todos os ficheiros desta pasta.
2. Abre **Settings → Pages**.
3. Em **Build and deployment**, escolhe **Deploy from a branch**.
4. Seleciona `main` e a pasta `/ (root)`; guarda.
5. Aguarda o GitHub publicar o site.


## Controlos
| Botão | Tecla virtual |
| --- | --- |
| D-pad | Setas |
| B | Z |
| A | X |
| L | A |
| R | S |
| Select | Shift |
| Start | Enter |

Os botões do layout enviam eventos de teclado para o emulador. A compatibilidade da captura de teclas depende da versão do EmulatorJS e do navegador.


## Motor de emulação
O EmulatorJS é uma dependência externa e é carregado da CDN `https://cdn.emulatorjs.org/stable/data/`. É necessário Internet para carregar o motor. O código do EmulatorJS não está incluído neste repositório.


## ROMs
Este projeto não inclui jogos. Usa apenas ROMs que tens autorização para utilizar. Seleciona um ficheiro compatível através de **ABRIR ROM**.


## Licença
O código de interface deste projeto é disponibilizado sob a licença MIT (ver `LICENSE`). EmulatorJS é um projeto separado e mantém a sua própria licença e termos.
