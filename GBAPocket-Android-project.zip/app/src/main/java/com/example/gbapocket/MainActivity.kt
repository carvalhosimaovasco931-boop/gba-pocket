package com.example.gbapocket

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.MotionEvent
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var gameScreen: TextView

    private val purple = Color.rgb(94, 66, 145)
    private val dark = Color.rgb(27, 24, 37)
    private val pickRom = registerForActivityResultCompat()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildUI()
    }

    private fun registerForActivityResultCompat(): Int = 1

    private fun buildUI() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
            setPadding(18, 14, 18, 14)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "GBA POCKET"
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val load = Button(this).apply {
            text = "OPEN ROM"
            setOnClickListener { openRomPicker() }
        }
        top.addView(load)
        root.addView(top)

        gameScreen = TextView(this).apply {
            text = "GBA Pocket\n\nChoose a .gba ROM to get started\n\nEmulation core not integrated yet"
            gravity = Gravity.CENTER
            textSize = 18f
            setTextColor(Color.rgb(190, 230, 205))
            setBackgroundColor(Color.rgb(12, 25, 18))
        }
        root.addView(gameScreen, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            setMargins(4, 10, 4, 12)
        })

        status = TextView(this).apply {
            text = "Ready • Touch controls"
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(status)

        val controlRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        controlRow.addView(makeDpad(), LinearLayout.LayoutParams(0, -1, 1f))
        controlRow.addView(makeSystemButtons(), LinearLayout.LayoutParams(0, -1, 0.9f))
        controlRow.addView(makeABButtons(), LinearLayout.LayoutParams(0, -1, 1f))
        root.addView(controlRow, LinearLayout.LayoutParams(-1, 170))
        setContentView(root)
    }

    private fun makeDpad(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        box.addView(button("▲", "UP"))
        val middle = LinearLayout(this).apply { gravity = Gravity.CENTER }
        middle.addView(button("◀", "LEFT"))
        middle.addView(button("●", "CENTER").apply { isEnabled = false; alpha = .25f })
        middle.addView(button("▶", "RIGHT"))
        box.addView(middle)
        box.addView(button("▼", "DOWN"))
        return box
    }

    private fun makeSystemButtons(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val shoulders = LinearLayout(this).apply { gravity = Gravity.CENTER }
        shoulders.addView(button("L", "L"))
        shoulders.addView(button("R", "R"))
        box.addView(shoulders)
        val center = LinearLayout(this).apply { gravity = Gravity.CENTER }
        center.addView(button("SELECT", "SELECT"))
        center.addView(button("START", "START"))
        box.addView(center)
        return box
    }

    private fun makeABButtons(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row.addView(button("B", "B"))
        row.addView(button("A", "A"))
        box.addView(row)
        return box
    }

    private fun button(label: String, control: String): Button {
        return Button(this).apply {
            text = label
            textSize = if (label.length > 2) 10f else 16f
            setTextColor(Color.WHITE)
            setBackgroundColor(purple)
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_DOWN) {
                    status.text = "$control pressed"
                    alpha = .65f
                } else if (event.action == MotionEvent.ACTION_UP ||
                    event.action == MotionEvent.ACTION_CANCEL) {
                    status.text = "Ready • Touch controls"
                    alpha = 1f
                }
                true
            }
        }
    }

    private fun openRomPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try {
            startActivityForResult(intent, pickRom)
        } catch (e: Exception) {
            status.text = "Unable to open file picker"
        }
    }

    @Deprecated("Legacy picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickRom && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                val name = uri.lastPathSegment ?: "Selected ROM"
                gameScreen.text = "ROM selected\n\n$name\n\nEmulation core not integrated yet"
                status.text = "ROM loaded: $name"
            }
        }
    }
}
