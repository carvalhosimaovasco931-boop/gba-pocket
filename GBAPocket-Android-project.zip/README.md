# GBA Pocket (Android)

Native Android project scaffold in Kotlin. This project is an Android app (not an HTML page).

## Open
Open this folder in Android Studio and allow Gradle sync.

## Build
- Build > Build APK(s)
- APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Current status
- Native Android UI and touch controls
- Landscape-oriented game screen
- Android document picker for `.gba` ROM files
- Button press visual feedback
- **No GBA emulation core is integrated yet.** Selecting a ROM currently displays its filename. CPU, memory, graphics and sound emulation still need a licensed/compatible core integration.

Use ROMs you are legally entitled to use.
